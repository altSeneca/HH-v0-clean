package com.hazardhawk.data.repositories

import com.hazardhawk.data.mocks.MockApiClient
import com.hazardhawk.data.repositories.crew.CertificationApiRepository
import com.hazardhawk.models.crew.*
import kotlinx.coroutines.test.runTest
import kotlinx.datetime.LocalDate
import kotlin.test.*

/**
 * Unit tests for CertificationApiRepository
 *
 * Tests all CRUD operations, verification workflows, and error handling
 */
class CertificationApiRepositoryTest {

    private lateinit var mockApi: MockApiClient
    private lateinit var repository: CertificationApiRepository

    @BeforeTest
    fun setup() {
        mockApi = MockApiClient()
        repository = CertificationApiRepository(apiClient = mockApi as Any as com.hazardhawk.data.network.ApiClient)
    }

    @AfterTest
    fun teardown() {
        mockApi.clearHistory()
    }

    // ===== Core CRUD Tests =====

    @Test
    fun `createCertification should call POST endpoint with correct payload`() = runTest {
        // Arrange
        val request = CreateCertificationRequest(
            certificationTypeId = "type_osha_10",
            issueDate = LocalDate(2025, 1, 15),
            expirationDate = LocalDate(2030, 1, 15),
            issuingAuthority = "OSHA Training Provider",
            certificationNumber = "OSHA10-2025-123456",
            documentUrl = "https://cdn.hazardhawk.com/certs/cert123.pdf"
        )

        // Act
        repository.createCertification(
            workerProfileId = "worker_123",
            companyId = "company_456",
            request = request
        )

        // Assert
        assertTrue(mockApi.verifyCalled("POST", "/api/certifications"))
        assertEquals(1, mockApi.countCalls("/api/certifications"))
    }

    @Test
    fun `getCertification should call GET endpoint with certification ID`() = runTest {
        // Act
        repository.getCertification(
            certificationId = "cert_123",
            includeType = true
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/certifications/cert_123"))
    }

    @Test
    fun `updateCertification should call PATCH endpoint with updated fields`() = runTest {
        // Act
        repository.updateCertification(
            certificationId = "cert_123",
            issueDate = LocalDate(2025, 2, 1),
            certificationNumber = "NEW-123"
        )

        // Assert
        assertTrue(mockApi.verifyCalled("PATCH", "/api/certifications/cert_123"))
    }

    @Test
    fun `deleteCertification should call DELETE endpoint`() = runTest {
        // Act
        repository.deleteCertification("cert_123")

        // Assert
        assertTrue(mockApi.verifyCalled("DELETE", "/api/certifications/cert_123"))
    }

    // ===== Query Tests =====

    @Test
    fun `getWorkerCertifications should call GET with worker ID`() = runTest {
        // Act
        repository.getWorkerCertifications(
            workerProfileId = "worker_123",
            status = CertificationStatus.VERIFIED,
            includeExpired = false
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/workers/worker_123/certifications"))
    }

    @Test
    fun `getCompanyCertifications should call GET with pagination params`() = runTest {
        // Act
        repository.getCompanyCertifications(
            companyId = "company_456",
            status = CertificationStatus.PENDING_VERIFICATION,
            pagination = PaginationRequest(pageSize = 20, cursor = "cursor_abc")
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications"))
        val lastCall = mockApi.getLastCall("/api/companies/company_456/certifications")
        assertNotNull(lastCall)
    }

    @Test
    fun `getCertificationsByType should filter by type and status`() = runTest {
        // Act
        repository.getCertificationsByType(
            companyId = "company_456",
            certificationTypeId = "type_osha_10",
            status = CertificationStatus.VERIFIED
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications"))
    }

    // ===== Verification Tests =====

    @Test
    fun `approveCertification should call POST approve endpoint`() = runTest {
        // Act
        repository.approveCertification(
            certificationId = "cert_123",
            verifiedBy = "safety_manager_789",
            notes = "All documents verified"
        )

        // Assert
        assertTrue(mockApi.verifyCalled("POST", "/api/certifications/cert_123/approve"))
    }

    @Test
    fun `rejectCertification should call POST reject endpoint with reason`() = runTest {
        // Act
        repository.rejectCertification(
            certificationId = "cert_123",
            verifiedBy = "safety_manager_789",
            reason = "Expired document"
        )

        // Assert
        assertTrue(mockApi.verifyCalled("POST", "/api/certifications/cert_123/reject"))
    }

    @Test
    fun `getPendingCertifications should call GET pending endpoint`() = runTest {
        // Act
        repository.getPendingCertifications(
            companyId = "company_456",
            limit = 50
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/pending"))
    }

    // ===== Expiration Tracking Tests =====

    @Test
    fun `getExpiringCertifications should call GET with days parameter`() = runTest {
        // Act
        repository.getExpiringCertifications(
            companyId = "company_456",
            daysUntilExpiration = 30
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/expiring"))
    }

    @Test
    fun `getExpiredCertifications should call GET expired endpoint`() = runTest {
        // Act
        repository.getExpiredCertifications(
            companyId = "company_456",
            limit = 100
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/expired"))
    }

    @Test
    fun `markCertificationsExpired should call POST with IDs array`() = runTest {
        // Act
        repository.markCertificationsExpired(
            certificationIds = listOf("cert_1", "cert_2", "cert_3")
        )

        // Assert
        assertTrue(mockApi.verifyCalled("POST", "/api/certifications/mark-expired"))
    }

    // ===== OCR and Document Processing Tests =====

    @Test
    fun `uploadCertificationDocument should call presigned URL endpoint first`() = runTest {
        // Arrange
        val documentData = ByteArray(1024) { it.toByte() }

        // Act
        repository.uploadCertificationDocument(
            workerProfileId = "worker_123",
            companyId = "company_456",
            documentData = documentData,
            fileName = "cert.pdf",
            mimeType = "application/pdf"
        )

        // Assert
        assertTrue(mockApi.verifyCalled("POST", "/api/storage/presigned-url"))
    }

    @Test
    fun `processCertificationOCR should create certification from OCR data`() = runTest {
        // Arrange
        val ocrData = OCRExtractedData(
            rawText = "OSHA 10 Certificate",
            holderName = "John Doe",
            certificationType = "OSHA_10",
            certificationNumber = "OSHA10-2025-123",
            issueDate = LocalDate(2025, 1, 1),
            expirationDate = LocalDate(2030, 1, 1),
            issuingAuthority = "OSHA",
            confidence = 0.95
        )

        // Act
        // Note: This will fail in mock, but verifies the flow
        repository.processCertificationOCR(
            workerProfileId = "worker_123",
            companyId = "company_456",
            documentUrl = "https://cdn.hazardhawk.com/cert.pdf",
            ocrData = ocrData
        )

        // Assert: Should attempt to fetch cert type by code
        assertTrue(mockApi.verifyCalled("GET", "/api/certification-types/by-code/OSHA_10"))
    }

    // ===== Certification Types Tests =====

    @Test
    fun `getCertificationTypes should call GET with region and category`() = runTest {
        // Act
        repository.getCertificationTypes(
            category = "safety_training",
            region = "US"
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/certification-types"))
    }

    @Test
    fun `getCertificationTypeByCode should call GET by-code endpoint`() = runTest {
        // Act
        repository.getCertificationTypeByCode("OSHA_10")

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/certification-types/by-code/OSHA_10"))
    }

    @Test
    fun `searchCertificationTypes should call search endpoint with query`() = runTest {
        // Act
        repository.searchCertificationTypes(
            query = "forklift",
            limit = 20
        )

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/certification-types/search"))
    }

    // ===== Statistics Tests =====

    @Test
    fun `getCertificationCountByStatus should call stats endpoint`() = runTest {
        // Act
        repository.getCertificationCountByStatus("company_456")

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/stats/by-status"))
    }

    @Test
    fun `getCertificationCountByType should call stats by-type endpoint`() = runTest {
        // Act
        repository.getCertificationCountByType("company_456")

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/stats/by-type"))
    }

    @Test
    fun `getComplianceMetrics should call compliance-metrics endpoint`() = runTest {
        // Act
        repository.getComplianceMetrics("company_456")

        // Assert
        assertTrue(mockApi.verifyCalled("GET", "/api/companies/company_456/certifications/compliance-metrics"))
    }

    // ===== Error Handling Tests =====

    @Test
    fun `createCertification should handle API errors gracefully`() = runTest {
        // Arrange
        val errorApi = MockApiClient(
            config = MockApiClient.MockApiConfig(shouldReturnErrors = true)
        )
        val errorRepo = CertificationApiRepository(apiClient = errorApi as Any as com.hazardhawk.data.network.ApiClient)

        val request = CreateCertificationRequest(
            certificationTypeId = "type_osha_10",
            issueDate = LocalDate(2025, 1, 1),
            documentUrl = "https://example.com/cert.pdf"
        )

        // Act
        val result = errorRepo.createCertification("worker_123", "company_456", request)

        // Assert
        assertTrue(result.isFailure)
    }

    @Test
    fun `uploadCertificationDocument should handle network failures with retry`() = runTest {
        // Arrange
        val unreliableApi = MockApiClient(
            config = MockApiClient.MockApiConfig(failureRate = 0.5)
        )
        val unreliableRepo = CertificationApiRepository(apiClient = unreliableApi as Any as com.hazardhawk.data.network.ApiClient)

        val documentData = ByteArray(512) { it.toByte() }

        // Act
        val result = unreliableRepo.uploadCertificationDocument(
            workerProfileId = "worker_123",
            companyId = "company_456",
            documentData = documentData,
            fileName = "test.pdf",
            mimeType = "application/pdf"
        )

        // Assert: May succeed or fail, but should not throw
        assertNotNull(result)
    }
}
