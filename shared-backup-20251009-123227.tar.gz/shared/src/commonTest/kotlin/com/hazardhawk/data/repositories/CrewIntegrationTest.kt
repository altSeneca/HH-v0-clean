package com.hazardhawk.data.repositories

import com.hazardhawk.FeatureFlags
import com.hazardhawk.data.mocks.MockApiClient
import com.hazardhawk.data.network.ApiClient
import com.hazardhawk.data.network.ApiResponse
import com.hazardhawk.data.network.AssignmentResponse
import com.hazardhawk.data.network.QRCodeResponse
import com.hazardhawk.data.network.SuccessResponse
import com.hazardhawk.models.crew.Crew
import com.hazardhawk.models.crew.CrewStatus
import com.hazardhawk.models.crew.CrewType
import com.hazardhawk.models.crew.CreateCrewRequest
import kotlinx.coroutines.test.runTest
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * Integration tests for Crew Service
 *
 * Tests complete workflows:
 * - Crew creation → QR generation → Assignment
 * - Multi-project assignments
 * - Validation rules
 * - End-to-end crew member management
 */
class CrewIntegrationTest {

    private lateinit var mockApiClient: MockApiClient
    private lateinit var repository: CrewApiRepository

    @BeforeTest
    fun setup() {
        FeatureFlags.API_CREW_ENABLED = true
        FeatureFlags.API_CACHE_ENABLED = false  // Disable cache for integration tests
        mockApiClient = MockApiClient()
    }

    // ========== Integration Test 1: Full Crew Creation → Assignment Flow ==========
    @Test
    fun `test complete crew creation to assignment workflow`() = runTest {
        // Arrange
        val createRequest = CreateCrewRequest(
            name = "Integration Test Crew",
            projectId = null,
            crewType = CrewType.GENERAL,
            trade = "General Construction",
            foremanId = "foreman-001",
            location = "Site A"
        )

        val createdCrew = Crew(
            id = "crew-integration-001",
            companyId = "company-001",
            projectId = null,
            name = "Integration Test Crew",
            crewType = CrewType.GENERAL,
            trade = "General Construction",
            foremanId = "foreman-001",
            location = "Site A",
            status = CrewStatus.ACTIVE,
            createdAt = "2025-01-01T10:00:00Z",
            updatedAt = "2025-01-01T10:00:00Z"
        )

        val qrResponse = QRCodeResponse(
            qrCodeUrl = "https://cdn.hazardhawk.com/qr/crew-integration-001.png",
            qrCodeData = "CREW:crew-integration-001",
            expiresAt = "2026-01-01T10:00:00Z"
        )

        val assignmentResponse = AssignmentResponse(
            assignmentId = "assignment-001",
            crewId = "crew-integration-001",
            projectId = "project-001",
            assignedAt = "2025-01-15T10:00:00Z",
            assignedBy = "admin-001"
        )

        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/crews" to ApiResponse(createdCrew),
                "/api/crews/crew-integration-001/qr-code" to qrResponse,
                "/api/projects/project-001/assign-crew" to assignmentResponse
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act - Step 1: Create crew
        val createResult = repository.createCrew(createRequest)
        assertTrue(createResult.isSuccess)
        val crew = createResult.getOrNull()
        assertNotNull(crew)
        assertEquals("crew-integration-001", crew.id)

        // Act - Step 2: Generate QR code
        val qrResult = repository.generateCrewQRCode(crew.id)
        assertTrue(qrResult.isSuccess)
        val qrCode = qrResult.getOrNull()
        assertNotNull(qrCode)
        assertEquals("CREW:crew-integration-001", qrCode.qrCodeData)

        // Act - Step 3: Assign to project
        val assignResult = repository.assignCrewToProject("project-001", crew.id)
        assertTrue(assignResult.isSuccess)
        val assignment = assignResult.getOrNull()
        assertNotNull(assignment)
        assertEquals("project-001", assignment.projectId)
        assertEquals(crew.id, assignment.crewId)

        // Assert - Verify call sequence
        assertTrue(mockApiClient.verifyCalled("POST", "/api/crews"))
        assertTrue(mockApiClient.verifyCalled("POST", "/api/crews/crew-integration-001/qr-code"))
        assertTrue(mockApiClient.verifyCalled("POST", "/api/projects/project-001/assign-crew"))
    }

    // ========== Integration Test 2: QR Code Generation and Scanning ==========
    @Test
    fun `test QR code generation for crew assignment`() = runTest {
        // Arrange
        val qrResponse = QRCodeResponse(
            qrCodeUrl = "https://cdn.hazardhawk.com/qr/crew-qr-001.png",
            qrCodeData = "CREW:crew-qr-001:ASSIGNMENT:project-002",
            expiresAt = "2025-12-31T23:59:59Z"
        )

        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/crews/crew-qr-001/qr-code" to qrResponse
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act
        val result = repository.generateCrewQRCode("crew-qr-001")

        // Assert
        assertTrue(result.isSuccess)
        val qr = result.getOrNull()
        assertNotNull(qr)
        assertEquals("CREW:crew-qr-001:ASSIGNMENT:project-002", qr.qrCodeData)
        assertNotNull(qr.expiresAt)
        assertTrue(mockApiClient.verifyCalled("POST", "/api/crews/crew-qr-001/qr-code"))
    }

    // ========== Integration Test 3: Multi-Project Assignments ==========
    @Test
    fun `test crew assigned to multiple projects`() = runTest {
        // Arrange
        val assignment1 = AssignmentResponse(
            assignmentId = "assignment-001",
            crewId = "crew-multi-001",
            projectId = "project-001",
            assignedAt = "2025-01-10T10:00:00Z",
            assignedBy = "admin-001"
        )

        val assignment2 = AssignmentResponse(
            assignmentId = "assignment-002",
            crewId = "crew-multi-001",
            projectId = "project-002",
            assignedAt = "2025-01-11T10:00:00Z",
            assignedBy = "admin-001"
        )

        val allAssignments = listOf(assignment1, assignment2)

        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/projects/project-001/assign-crew" to assignment1,
                "/api/projects/project-002/assign-crew" to assignment2,
                "/api/crews/crew-multi-001/assignments" to ApiResponse(allAssignments)
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act - Assign to first project
        val assign1 = repository.assignCrewToProject("project-001", "crew-multi-001")
        assertTrue(assign1.isSuccess)

        // Act - Assign to second project
        val assign2 = repository.assignCrewToProject("project-002", "crew-multi-001")
        assertTrue(assign2.isSuccess)

        // Act - Get all assignments
        val assignmentsResult = repository.getCrewAssignments("crew-multi-001")
        assertTrue(assignmentsResult.isSuccess)
        val assignments = assignmentsResult.getOrNull()
        assertNotNull(assignments)
        assertEquals(2, assignments.size)
        assertEquals("project-001", assignments[0].projectId)
        assertEquals("project-002", assignments[1].projectId)
    }

    // ========== Integration Test 4: Unassign Crew from Project ==========
    @Test
    fun `test unassign crew from project`() = runTest {
        // Arrange
        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/projects/project-001/crews/crew-001" to SuccessResponse(
                    success = true,
                    message = "Crew unassigned successfully"
                )
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act
        val result = repository.unassignCrewFromProject("project-001", "crew-001")

        // Assert
        assertTrue(result.isSuccess)
        assertTrue(result.getOrNull() == true)
        assertTrue(mockApiClient.verifyCalled("DELETE", "/api/projects/project-001/crews/crew-001"))
    }

    // ========== Integration Test 5: Validation Rules - Name Length ==========
    @Test
    fun `test crew name validation rejects short names`() = runTest {
        // Arrange
        val invalidRequest = CreateCrewRequest(
            name = "AB",  // Too short (< 3 characters)
            projectId = null,
            crewType = CrewType.GENERAL,
            trade = null,
            foremanId = null,
            location = null
        )

        mockApiClient = MockApiClient()
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act
        val result = repository.createCrew(invalidRequest)

        // Assert
        assertTrue(result.isFailure)
        assertEquals("Crew name must be at least 3 characters long", result.exceptionOrNull()?.message)
    }

    // ========== Integration Test 6: Validation Rules - Name Too Long ==========
    @Test
    fun `test crew name validation rejects long names`() = runTest {
        // Arrange
        val longName = "A".repeat(101)  // 101 characters, over limit
        val invalidRequest = CreateCrewRequest(
            name = longName,
            projectId = null,
            crewType = CrewType.GENERAL,
            trade = null,
            foremanId = null,
            location = null
        )

        mockApiClient = MockApiClient()
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act
        val result = repository.createCrew(invalidRequest)

        // Assert
        assertTrue(result.isFailure)
        assertEquals("Crew name must be less than 100 characters", result.exceptionOrNull()?.message)
    }

    // ========== Integration Test 7: Role Synchronization ==========
    @Test
    fun `test sync crew roles updates permissions`() = runTest {
        // Arrange
        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/crews/crew-sync-001/sync-roles" to SuccessResponse(
                    success = true,
                    message = "Roles synchronized successfully"
                )
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act
        val result = repository.syncCrewRoles("crew-sync-001")

        // Assert
        assertTrue(result.isSuccess)
        assertTrue(result.getOrNull() == true)
        assertTrue(mockApiClient.verifyCalled("POST", "/api/crews/crew-sync-001/sync-roles"))
    }

    // ========== Integration Test 8: Complete Member Management Flow ==========
    @Test
    fun `test complete crew member lifecycle - add, update role, remove`() = runTest {
        // Arrange
        val memberId = "member-lifecycle-001"
        val crewId = "crew-lifecycle-001"

        val config = MockApiClient.MockApiConfig(
            customResponses = mapOf(
                "/api/crews/$crewId/members" to ApiResponse(
                    com.hazardhawk.models.crew.CrewMember(
                        id = memberId,
                        crewId = crewId,
                        companyWorkerId = "worker-001",
                        role = com.hazardhawk.models.crew.CrewMemberRole.MEMBER,
                        startDate = kotlinx.datetime.LocalDate(2025, 1, 15),
                        endDate = null,
                        status = "active",
                        worker = null
                    )
                ),
                "/api/crews/$crewId/members/$memberId" to ApiResponse(
                    com.hazardhawk.models.crew.CrewMember(
                        id = memberId,
                        crewId = crewId,
                        companyWorkerId = "worker-001",
                        role = com.hazardhawk.models.crew.CrewMemberRole.LEAD,
                        startDate = kotlinx.datetime.LocalDate(2025, 1, 15),
                        endDate = null,
                        status = "active",
                        worker = null
                    )
                ),
                "/api/crews/$crewId/members/$memberId" to SuccessResponse(success = true)
            )
        )
        mockApiClient = MockApiClient(config)
        val apiClient = createMockApiClient(mockApiClient)
        repository = CrewApiRepository(apiClient)

        // Act - Step 1: Add member
        val addResult = repository.addCrewMember(crewId, "worker-001", "member")
        assertTrue(addResult.isSuccess)
        val member = addResult.getOrNull()
        assertNotNull(member)
        assertEquals(memberId, member.id)

        // Act - Step 2: Update member role
        val updateResult = repository.updateCrewMemberRole(crewId, memberId, "lead")
        assertTrue(updateResult.isSuccess)
        val updatedMember = updateResult.getOrNull()
        assertNotNull(updatedMember)
        assertEquals(com.hazardhawk.models.crew.CrewMemberRole.LEAD, updatedMember.role)

        // Act - Step 3: Remove member
        val removeResult = repository.removeCrewMember(crewId, memberId)
        assertTrue(removeResult.isSuccess)

        // Assert - Verify all operations were called
        assertTrue(mockApiClient.verifyCalled("POST", "/api/crews/$crewId/members"))
        assertTrue(mockApiClient.verifyCalled("PATCH", "/api/crews/$crewId/members/$memberId"))
        assertTrue(mockApiClient.verifyCalled("DELETE", "/api/crews/$crewId/members/$memberId"))
    }

    // ========== Helper: Create Mock ApiClient Wrapper ==========
    private fun createMockApiClient(mockClient: MockApiClient): ApiClient {
        return ApiClient(baseUrl = "http://mock-api.test")
    }
}
