package com.hazardhawk

/**
 * Feature flags for Phase 2 backend integration
 *
 * Controls which features use real API vs mock implementations
 */
object FeatureFlags {
    /**
     * Enable crew service API integration
     * When true: Uses CrewApiRepository with real backend
     * When false: Uses mock implementation
     */
    var API_CREW_ENABLED: Boolean = getEnvBool("API_CREW_ENABLED", false)

    /**
     * Enable project service API integration
     * When true: Uses ProjectApiRepository with real backend
     * When false: Uses mock implementation
     */
    var API_PROJECT_ENABLED: Boolean = getEnvBool("API_PROJECT_ENABLED", false)

    /**
     * Enable company service API integration
     * When true: Uses CompanyApiRepository with real backend
     * When false: Uses mock implementation
     */
    var API_COMPANY_ENABLED: Boolean = getEnvBool("API_COMPANY_ENABLED", false)

    /**
     * Enable certification service API integration
     * When true: Uses CertificationApiRepository with real backend
     * When false: Uses mock implementation
     */
    var API_CERTIFICATION_ENABLED: Boolean = getEnvBool("API_CERTIFICATION_ENABLED", false)

    /**
     * Enable dashboard service API integration
     * When true: Uses DashboardApiRepository with real backend
     * When false: Uses mock implementation
     */
    var API_DASHBOARD_ENABLED: Boolean = getEnvBool("API_DASHBOARD_ENABLED", false)

    /**
     * Base URL for backend API
     */
    var API_BASE_URL: String = getEnvString("API_BASE_URL", "https://dev-api.hazardhawk.com")

    /**
     * API timeout in milliseconds
     */
    var API_TIMEOUT_MS: Long = getEnvLong("API_TIMEOUT_MS", 30000L)

    /**
     * Enable request/response logging
     */
    var API_LOGGING_ENABLED: Boolean = getEnvBool("API_LOGGING_ENABLED", true)

    /**
     * Enable caching for GET requests
     */
    var API_CACHE_ENABLED: Boolean = getEnvBool("API_CACHE_ENABLED", true)

    /**
     * Cache TTL in seconds
     */
    var API_CACHE_TTL_SECONDS: Long = getEnvLong("API_CACHE_TTL_SECONDS", 300L)

    // Helper functions for environment variables (KMP compatible)
    private fun getEnvBool(key: String, default: Boolean): Boolean {
        return try {
            System.getenv(key)?.toBoolean() ?: default
        } catch (e: Exception) {
            default
        }
    }

    private fun getEnvString(key: String, default: String): String {
        return try {
            System.getenv(key) ?: default
        } catch (e: Exception) {
            default
        }
    }

    private fun getEnvLong(key: String, default: Long): Long {
        return try {
            System.getenv(key)?.toLongOrNull() ?: default
        } catch (e: Exception) {
            default
        }
    }
}
