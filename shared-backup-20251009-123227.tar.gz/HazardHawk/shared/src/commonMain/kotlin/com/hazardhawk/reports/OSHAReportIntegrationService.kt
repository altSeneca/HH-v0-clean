package com.hazardhawk.reports

import com.hazardhawk.data.repositories.OSHAAnalysisRepository
import com.hazardhawk.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.datetime.Clock

/**
 * Service for integrating OSHA analysis data into safety reports
 * Handles aggregation and formatting of analysis results for report generation
 */
interface OSHAReportIntegrationService {
    /**
     * Get OSHA analysis data for a specific report
     */
    suspend fun getOSHADataForReport(reportId: String, photoIds: List<String>): Result<OSHAReportData>

    /**
     * Get OSHA compliance summary for a date range
     */
    suspend fun getComplianceSummary(startDate: Long, endDate: Long): Result<OSHAComplianceSummary>

    /**
     * Generate OSHA violations section for safety reports
     */
    suspend fun generateViolationsSection(photoIds: List<String>): Result<OSHAViolationsSection>

    /**
     * Get trending safety data for dashboard reports
     */
    suspend fun getTrendingData(timeframe: ReportTimeframe): Result<OSHATrendingData>
}

/**
 * Implementation of OSHA report integration service
 */
class OSHAReportIntegrationServiceImpl(
    private val oshaAnalysisRepository: OSHAAnalysisRepository
) : OSHAReportIntegrationService {

    override suspend fun getOSHADataForReport(reportId: String, photoIds: List<String>): Result<OSHAReportData> {
        return try {
            val analyses = mutableListOf<Pair<String, OSHAAnalysisResult>>()

            // Collect all OSHA analyses for the specified photos
            photoIds.forEach { photoId ->
                oshaAnalysisRepository.getAnalysis(photoId).fold(
                    onSuccess = { analysisResult ->
                        if (analysisResult != null) {
                            analyses.add(photoId to analysisResult)
                        }
                    },
                    onFailure = { /* Continue with other photos */ }
                )
            }

            val reportData = OSHAReportData(
                reportId = reportId,
                totalPhotosAnalyzed = analyses.size,
                totalViolations = analyses.sumOf { it.second.oshaViolations.size },
                averageComplianceScore = if (analyses.isNotEmpty()) {
                    analyses.map { it.second.complianceScore }.average()
                } else 0.0,
                photoAnalyses = analyses.toMap(),
                violationsBySeverity = aggregateViolationsBySeverity(analyses),
                violationsByStandard = aggregateViolationsByStandard(analyses),
                complianceRecommendations = generateComplianceRecommendations(analyses),
                generatedAt = Clock.System.now().toEpochMilliseconds()
            )

            Result.success(reportData)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getComplianceSummary(startDate: Long, endDate: Long): Result<OSHAComplianceSummary> {
        return try {
            oshaAnalysisRepository.getAnalysesByDateRange(startDate, endDate).fold(
                onSuccess = { analyses ->
                    val summary = OSHAComplianceSummary(
                        timeframe = "$startDate-$endDate",
                        totalAnalyses = analyses.size,
                        averageComplianceScore = if (analyses.isNotEmpty()) {
                            analyses.map { it.second.complianceScore }.average()
                        } else 0.0,
                        criticalViolations = analyses.flatMap { it.second.oshaViolations }
                            .count { it.violationType == OSHAViolationType.SERIOUS },
                        highViolations = analyses.flatMap { it.second.oshaViolations }
                            .count { it.violationType == OSHAViolationType.OTHER_THAN_SERIOUS },
                        mediumViolations = analyses.flatMap { it.second.oshaViolations }
                            .count { it.violationType == OSHAViolationType.DE_MINIMIS },
                        lowViolations = analyses.flatMap { it.second.oshaViolations }
                            .count { it.violationType == OSHAViolationType.WILLFUL },
                        mostCommonViolations = getMostCommonViolations(analyses),
                        complianceRate = calculateComplianceRate(analyses),
                        generatedAt = Clock.System.now().toEpochMilliseconds()
                    )
                    Result.success(summary)
                },
                onFailure = { Result.failure(it) }
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun generateViolationsSection(photoIds: List<String>): Result<OSHAViolationsSection> {
        return try {
            val allViolations = mutableListOf<OSHAViolationWithPhoto>()

            photoIds.forEach { photoId ->
                oshaAnalysisRepository.getAnalysis(photoId).fold(
                    onSuccess = { analysisResult ->
                        analysisResult?.oshaViolations?.forEach { violation ->
                            allViolations.add(
                                OSHAViolationWithPhoto(
                                    photoId = photoId,
                                    violation = violation
                                )
                            )
                        }
                    },
                    onFailure = { /* Continue with other photos */ }
                )
            }

            // Group and sort violations
            val criticalViolations = allViolations.filter { it.violation.violationType == OSHAViolationType.SERIOUS }
                .sortedBy { it.violation.oshaStandard }
            val highViolations = allViolations.filter { it.violation.violationType == OSHAViolationType.OTHER_THAN_SERIOUS }
                .sortedBy { it.violation.oshaStandard }
            val otherViolations = allViolations.filter {
                it.violation.violationType == OSHAViolationType.DE_MINIMIS || it.violation.violationType == OSHAViolationType.WILLFUL
            }.sortedBy { it.violation.oshaStandard }

            val section = OSHAViolationsSection(
                criticalViolations = criticalViolations,
                highViolations = highViolations,
                otherViolations = otherViolations,
                totalViolations = allViolations.size,
                summary = generateViolationsSummary(allViolations)
            )

            Result.success(section)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getTrendingData(timeframe: ReportTimeframe): Result<OSHATrendingData> {
        return try {
            val endTime = Clock.System.now().toEpochMilliseconds()
            val startTime = when (timeframe) {
                ReportTimeframe.LAST_7_DAYS -> endTime - (7 * 24 * 60 * 60 * 1000L)
                ReportTimeframe.LAST_30_DAYS -> endTime - (30 * 24 * 60 * 60 * 1000L)
                ReportTimeframe.LAST_90_DAYS -> endTime - (90 * 24 * 60 * 60 * 1000L)
                ReportTimeframe.LAST_YEAR -> endTime - (365 * 24 * 60 * 60 * 1000L)
            }

            oshaAnalysisRepository.getAnalysesByDateRange(startTime, endTime).fold(
                onSuccess = { analyses ->
                    val trendingData = OSHATrendingData(
                        timeframe = timeframe,
                        totalAnalyses = analyses.size,
                        complianceScoreTrend = calculateComplianceTrend(analyses),
                        violationTrends = calculateViolationTrends(analyses),
                        improvementAreas = identifyImprovementAreas(analyses),
                        safetyScore = calculateOverallSafetyScore(analyses),
                        generatedAt = endTime
                    )
                    Result.success(trendingData)
                },
                onFailure = { Result.failure(it) }
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun aggregateViolationsBySeverity(analyses: List<Pair<String, OSHAAnalysisResult>>): Map<OSHAViolationType, Int> {
        return analyses.flatMap { it.second.oshaViolations }
            .groupBy { it.violationType }
            .mapValues { it.value.size }
    }

    private fun aggregateViolationsByStandard(analyses: List<Pair<String, OSHAAnalysisResult>>): Map<String, Int> {
        return analyses.flatMap { it.second.oshaViolations }
            .groupBy { it.oshaStandard }
            .mapValues { it.value.size }
    }

    private fun generateComplianceRecommendations(analyses: List<Pair<String, OSHAAnalysisResult>>): List<String> {
        val allViolations = analyses.flatMap { it.second.oshaViolations }
        val recommendations = mutableListOf<String>()

        // Get most common violation types
        val commonViolations = allViolations.groupBy { it.oshaStandard }
            .toList()
            .sortedByDescending { it.second.size }
            .take(3)

        commonViolations.forEach { (standard, violations) ->
            recommendations.add("Address recurring ${standard} violations (${violations.size} instances)")
        }

        // Add severity-based recommendations
        val criticalCount = allViolations.count { it.violationType == OSHAViolationType.SERIOUS }
        if (criticalCount > 0) {
            recommendations.add("Immediate action required for $criticalCount critical safety violations")
        }

        return recommendations
    }

    private fun getMostCommonViolations(analyses: List<Pair<String, OSHAAnalysisResult>>): List<String> {
        return analyses.flatMap { it.second.oshaViolations }
            .groupBy { it.oshaStandard }
            .toList()
            .sortedByDescending { it.second.size }
            .take(5)
            .map { "${it.first} (${it.second.size} occurrences)" }
    }

    private fun calculateComplianceRate(analyses: List<Pair<String, OSHAAnalysisResult>>): Double {
        if (analyses.isEmpty()) return 100.0

        val totalAnalyses = analyses.size
        val compliantAnalyses = analyses.count { it.second.oshaViolations.isEmpty() }

        return (compliantAnalyses.toDouble() / totalAnalyses) * 100.0
    }

    private fun generateViolationsSummary(violations: List<OSHAViolationWithPhoto>): String {
        return when {
            violations.isEmpty() -> "No OSHA violations detected in analyzed photos."
            violations.count { it.violation.violationType == OSHAViolationType.SERIOUS } > 0 ->
                "Critical safety violations require immediate attention."
            violations.count { it.violation.violationType == OSHAViolationType.OTHER_THAN_SERIOUS } > 0 ->
                "High priority safety issues identified for prompt resolution."
            else -> "Safety violations detected - review and address as appropriate."
        }
    }

    private fun calculateComplianceTrend(analyses: List<Pair<String, OSHAAnalysisResult>>): List<Double> {
        // Simplified trend calculation - in production, this would be more sophisticated
        return analyses.map { it.second.complianceScore.toDouble() }
    }

    private fun calculateViolationTrends(analyses: List<Pair<String, OSHAAnalysisResult>>): Map<OSHAViolationType, List<Int>> {
        // Simplified trend calculation for each violation type level
        val trends = mutableMapOf<OSHAViolationType, MutableList<Int>>()

        analyses.forEach { (_, analysis) ->
            analysis.oshaViolations.groupBy { it.violationType }.forEach { (violationType, violationList) ->
                trends.getOrPut(violationType) { mutableListOf() }.add(violationList.size)
            }
        }

        return trends.mapValues { it.value.toList() }
    }

    private fun identifyImprovementAreas(analyses: List<Pair<String, OSHAAnalysisResult>>): List<String> {
        val allViolations = analyses.flatMap { it.second.oshaViolations }

        return allViolations.groupBy { it.oshaStandard }
            .filter { it.value.size >= 2 } // Areas with multiple violations
            .keys
            .take(3)
            .map { "Focus on improving compliance with $it" }
    }

    private fun calculateOverallSafetyScore(analyses: List<Pair<String, OSHAAnalysisResult>>): Double {
        if (analyses.isEmpty()) return 100.0

        return analyses.map { it.second.complianceScore.toDouble() }.average()
    }
}

/**
 * Data model for OSHA report integration
 */
@kotlinx.serialization.Serializable
data class OSHAReportData(
    val reportId: String,
    val totalPhotosAnalyzed: Int,
    val totalViolations: Int,
    val averageComplianceScore: Double,
    val photoAnalyses: Map<String, OSHAAnalysisResult>,
    val violationsBySeverity: Map<OSHAViolationType, Int>,
    val violationsByStandard: Map<String, Int>,
    val complianceRecommendations: List<String>,
    val generatedAt: Long
)

/**
 * OSHA compliance summary for time-based reports
 */
@kotlinx.serialization.Serializable
data class OSHAComplianceSummary(
    val timeframe: String,
    val totalAnalyses: Int,
    val averageComplianceScore: Double,
    val criticalViolations: Int,
    val highViolations: Int,
    val mediumViolations: Int,
    val lowViolations: Int,
    val mostCommonViolations: List<String>,
    val complianceRate: Double,
    val generatedAt: Long
)

/**
 * OSHA violations section for safety reports
 */
@kotlinx.serialization.Serializable
data class OSHAViolationsSection(
    val criticalViolations: List<OSHAViolationWithPhoto>,
    val highViolations: List<OSHAViolationWithPhoto>,
    val otherViolations: List<OSHAViolationWithPhoto>,
    val totalViolations: Int,
    val summary: String
)

/**
 * OSHA violation with associated photo ID
 */
@kotlinx.serialization.Serializable
data class OSHAViolationWithPhoto(
    val photoId: String,
    val violation: OSHAViolation
)

/**
 * Trending data for OSHA compliance analytics
 */
@kotlinx.serialization.Serializable
data class OSHATrendingData(
    val timeframe: ReportTimeframe,
    val totalAnalyses: Int,
    val complianceScoreTrend: List<Double>,
    val violationTrends: Map<OSHAViolationType, List<Int>>,
    val improvementAreas: List<String>,
    val safetyScore: Double,
    val generatedAt: Long
)

/**
 * Report timeframe options
 */
enum class ReportTimeframe {
    LAST_7_DAYS,
    LAST_30_DAYS,
    LAST_90_DAYS,
    LAST_YEAR
}