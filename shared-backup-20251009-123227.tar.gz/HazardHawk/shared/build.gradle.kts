plugins {
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.androidLibrary)
    alias(libs.plugins.sqlDelight)
    alias(libs.plugins.kotlinSerialization)
}

kotlin {
    androidTarget {
        compilations.all {
            kotlinOptions {
                jvmTarget = "11"
            }
        }
    }
    
    // iOS targets for full multiplatform support
    iosX64()
    iosArm64()
    iosSimulatorArm64()

    sourceSets {
        val commonMain by getting {
            kotlin.srcDir("src/commonMain/kotlin")
            
            dependencies {
                // Core coroutines and serialization
                implementation(libs.kotlinx.coroutines.core)
                implementation(libs.kotlinx.serialization.json)
                implementation(libs.kotlinx.datetime)
                implementation(libs.uuid)
                
                // Networking with Ktor
                implementation(libs.bundles.ktor.client)
                
                // Database
                implementation(libs.bundles.sqldelight)
                
                // Dependency injection
                implementation(libs.koin.core)
                
                // Glass morphism and blur effects
                implementation(libs.haze)
                
            }
        }
        
        val androidMain by getting {
            
            dependencies {
                // Platform-specific database driver
                implementation(libs.sqldelight.android.driver)
                
                // Android-specific HTTP client
                implementation(libs.ktor.client.android)
                implementation(libs.ktor.client.auth)
                
                // AndroidX Core
                implementation(libs.androidx.core.ktx)
                implementation(libs.androidx.lifecycle.viewmodel)
                
                // Security libraries for Android Keystore and encryption
                implementation("androidx.security:security-crypto:1.1.0-alpha06")
                implementation("androidx.security:security-identity-credential:1.0.0-alpha03")
                
                // AI and ML libraries - updated versions for better compatibility
                implementation(libs.bundles.ai.ml)
                implementation(libs.tensorflow.lite.gpu)
                implementation(libs.tensorflow.lite.support)
                
                // Firebase AI and Vertex AI for Gemini integration
                implementation(libs.firebase.vertexai)
                implementation(libs.generativeai)
                
                // AWS SDK for cloud services (Android only)
                implementation(libs.aws.sdk.cognitoidentityprovider)
                implementation(libs.aws.sdk.s3)
                
                // Image processing utilities
                implementation(libs.exifinterface)
            }
        }
        
        val androidUnitTest by getting {
            dependencies {
                // Android-specific test dependencies that support mockk
                implementation(libs.junit)
                implementation(libs.mockk)
                implementation(libs.robolectric)
            }
        }
        
        val androidInstrumentedTest by getting {
            dependencies {
                // Android instrumentation test dependencies
                implementation("androidx.test.ext:junit:1.1.5")
                implementation("androidx.test:runner:1.5.2")
                implementation("androidx.test:rules:1.5.0")
                implementation("androidx.test.espresso:espresso-core:3.5.1")
                implementation(libs.kotlinx.coroutines.test)
            }
        }
        
        val iosX64Main by getting
        val iosArm64Main by getting
        val iosSimulatorArm64Main by getting
        val iosMain by creating {
            dependsOn(commonMain)
            iosX64Main.dependsOn(this)
            iosArm64Main.dependsOn(this)
            iosSimulatorArm64Main.dependsOn(this)
            
            dependencies {
                // Platform-specific database driver
                implementation(libs.sqldelight.native.driver)
                
                // iOS-specific HTTP client
                implementation(libs.ktor.client.darwin)
            }
        }
        
        val commonTest by getting {
            dependencies {
                // Use only KMP-compatible test dependencies
                implementation(libs.kotlin.test)
                implementation(libs.kotlinx.coroutines.test)
                implementation(libs.kotlinx.serialization.json)
            }
        }
        
        val iosX64Test by getting
        val iosArm64Test by getting
        val iosSimulatorArm64Test by getting
        val iosTest by creating {
            dependsOn(commonTest)
            iosX64Test.dependsOn(this)
            iosArm64Test.dependsOn(this)
            iosSimulatorArm64Test.dependsOn(this)
        }
    }
}

android {
    namespace = "com.hazardhawk.shared"
    compileSdk = 35
    defaultConfig {
        minSdk = 26
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

sqldelight {
    databases {
        create("HazardHawkDatabase") {
            packageName.set("com.hazardhawk.database")
            srcDirs.from("src/commonMain/sqldelight")
        }
    }
}
// ============================================================================
// Phase 2 Testing Configuration
// ============================================================================

// Configure test task with detailed logging
tasks.withType<Test> {
    useJUnitPlatform()
    
    testLogging {
        events("passed", "skipped", "failed", "standardOut", "standardError")
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
        showExceptions = true
        showCauses = true
        showStackTraces = true
    }
    
    // Increase max heap size for tests
    maxHeapSize = "2g"
    
    // Enable parallel test execution
    maxParallelForks = Runtime.getRuntime().availableProcessors().div(2).coerceAtLeast(1)
    
    reports {
        html.required.set(true)
        junitXml.required.set(true)
    }
}

// Integration test task
tasks.register<Test>("integrationTest") {
    description = "Runs integration tests with external service dependencies"
    group = "verification"
    
    useJUnitPlatform {
        includeTags("integration")
    }
    
    filter {
        includeTestsMatching("*IntegrationTest")
        includeTestsMatching("*IT")
    }
    
    // shouldRunAfter(tasks.named("test")) // Disabled: KMP projects dont have single test task
    
    testLogging {
        events("passed", "skipped", "failed")
        showStandardStreams = true
    }
}

// E2E test task
tasks.register<Test>("e2eTest") {
    description = "Runs end-to-end tests"
    group = "verification"
    
    useJUnitPlatform {
        includeTags("e2e")
    }
    
    filter {
        includeTestsMatching("*E2ETest")
        includeTestsMatching("*EndToEndTest")
    }
    
    shouldRunAfter(tasks.named("integrationTest"))
    
    testLogging {
        events("passed", "skipped", "failed")
        showStandardStreams = true
    }
}

// JaCoCo coverage configuration
apply(plugin = "jacoco")

tasks.register<JacocoReport>("jacocoTestReport") {
    // dependsOn(tasks.named("test")) // Disabled: KMP projects dont have single test task
    
    reports {
        xml.required.set(true)
        html.required.set(true)
        csv.required.set(false)
    }
    
    classDirectories.setFrom(
        fileTree(project.buildDir) {
            include("**/classes/kotlin/android/**")
            exclude(
                "**/BuildConfig.*",
                "**/*Test*.*",
                "**/*\$*.*",
                "**/test/**",
                "**/androidTest/**"
            )
        }
    )
    
    sourceDirectories.setFrom(files("src/commonMain/kotlin", "src/androidMain/kotlin"))
    executionData.setFrom(fileTree(project.buildDir) {
        include("jacoco/*.exec", "outputs/unit_test_code_coverage/**/testDebugUnitTest.exec")
    })
}

// Coverage verification
tasks.register<JacocoCoverageVerification>("jacocoTestCoverageVerification") {
    dependsOn(tasks.named("jacocoTestReport"))
    
    violationRules {
        rule {
            limit {
                minimum = "0.80".toBigDecimal()
            }
        }
        
        rule {
            element = "CLASS"
            limit {
                minimum = "0.75".toBigDecimal()
            }
            
            excludes = listOf(
                "*.BuildConfig",
                "*Test",
                "*\$*"
            )
        }
    }
}

// Make check task depend on coverage verification
tasks.named("check") {
    dependsOn(tasks.named("jacocoTestCoverageVerification"))
}
